package spark

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext

object readfile extends App {
 val conf = new SparkConf().setAppName("Test").setMaster("local[*]")
 val sc = new SparkContext(conf)
 val spark = org.apache.spark.sql.SparkSession.builder
 .master("local")
 .appName("Spark CSV Reader")
 .getOrCreate;
 val tsvfile = spark.read.format("csv").option("header","true")
 .option("mode","DROPMALFORMED")
 .option("delimiter", "\t")
 .load("D:\\_DESKTOP\\Documentos\\P�S\\PROCESSAMENTO HADOOP E MAPREDUCE (POS-CDBD-20193)\\2004-2019.tsv")
 //tsvfile.show(1);
 tsvfile.createOrReplaceTempView("gas")
 val df = spark.sqlContext.sql("Select * from gas where estado like 'S%'")
.orderBy("estado").show(10)
 //tsvfile.show();
 sc.stop()
}