package spark

import org.apache.spark.streaming.StreamingContext
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.streaming.Seconds

object straming extends App {
 val conf = new SparkConf().setAppName("Stream").setMaster("local[2]")
 val sc = new SparkContext(conf)
 val ssc = new StreamingContext(sc, Seconds(3))
 val streamRDD = ssc.socketTextStream("127.0.0.1",9999)
 val wordcounts = streamRDD.flatMap(line => line.split(" ")).map(word => (word,1))
 val wordcounts2 = streamRDD.reduce(_+_)
 wordcounts.print()
 wordcounts2.print()
 ssc.start()
 ssc.awaitTermination()
}
//nc -lk 9999 linha de codigo no mobaXterm