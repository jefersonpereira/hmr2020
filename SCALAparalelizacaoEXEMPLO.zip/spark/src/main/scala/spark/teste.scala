package spark

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext


object teste extends App {
  val conf = new SparkConf().setAppName("Test").setMaster("local[*]")
  val sc = new SparkContext(conf)
  println("ok")

  sc.stop()
}